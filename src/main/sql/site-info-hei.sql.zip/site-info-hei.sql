-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 10 déc. 2020 à 16:14
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `site-info-hei`
--

-- --------------------------------------------------------

--
-- Structure de la table `eleve`
--

CREATE TABLE `eleve` (
  `eleve_id` int(11) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `year` int(3) NOT NULL,
  `domaine` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `eleve`
--

INSERT INTO `eleve` (`eleve_id`, `nom`, `prenom`, `year`, `domaine`) VALUES
(4, 'Paturel', 'Ronan', 4, 'ITI'),
(10, 'DeForesta', 'Martin', 4, 'ITI'),
(11, 'Desclodures', 'Eliott', 4, 'ITI'),
(12, 'Fauchet', 'Corentin', 4, 'ITI');

-- --------------------------------------------------------

--
-- Structure de la table `identifiant`
--

CREATE TABLE `identifiant` (
  `nomUtil` varchar(30) NOT NULL,
  `Mdp` varchar(100) NOT NULL,
  `Admin` tinyint(1) NOT NULL,
  `eleve_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `identifiant`
--

INSERT INTO `identifiant` (`nomUtil`, `Mdp`, `Admin`, `eleve_id`) VALUES
('DeForesta.Martin', '$argon2i$v=19$m=65536,t=22,p=1$FEsVNd2yRI6fKQp0q8HDGw$6HKkQ44+mmLVlHzuFCoyXLwG2mqT1++BmbJ0ev4frpw', 0, 10),
('Desclodures.Eliott', '$argon2i$v=19$m=65536,t=22,p=1$Ww/WQ9DjLh14li0RlRzwxw$b9gXDaSH05eHnxw98ruoPJAHUKyUCWRqkcKhJJb78Xk', 0, 11),
('Fauchet.Corentin', '$argon2i$v=19$m=65536,t=22,p=1$J5bm+w1vkOJaaQMVPkEGVQ$dt8S/hHqtisW8cdf1NPv+fNPCrGqu28kpOHEv4/u2uU', 0, 12),
('Ronan', '$argon2i$v=19$m=65536,t=22,p=1$+0I+XAJBRoSGkKczm/wzqA$mZv9qrL0Cm0rZ4BisBo6yArTa8hUstdWy06SLTV11SY', 1, 4);

-- --------------------------------------------------------

--
-- Structure de la table `nn`
--

CREATE TABLE `nn` (
  `eleve_id` int(11) NOT NULL,
  `tea_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `nn`
--

INSERT INTO `nn` (`eleve_id`, `tea_id`) VALUES
(12, 14),
(12, 12),
(12, 5),
(12, 10),
(12, 15),
(12, 9),
(10, 11),
(10, 12),
(10, 10),
(10, 9),
(10, 5),
(10, 15),
(11, 10),
(11, 12),
(11, 11),
(11, 14),
(11, 5),
(11, 15),
(11, 9),
(11, 13);

-- --------------------------------------------------------

--
-- Structure de la table `tea`
--

CREATE TABLE `tea` (
  `tea_id` int(11) NOT NULL,
  `title` varchar(45) NOT NULL,
  `release_date` date NOT NULL,
  `duration` int(11) NOT NULL,
  `valide` tinyint(1) NOT NULL,
  `nbrDispo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tea`
--

INSERT INTO `tea` (`tea_id`, `title`, `release_date`, `duration`, `valide`, `nbrDispo`) VALUES
(5, 'Forum HEI', '2021-10-10', 2, 1, 5),
(6, 'Salon Marseille', '2020-10-12', 4, 0, 10),
(7, 'Aide une asso avec un moyen de locomotion', '2020-10-06', 3, 0, 6),
(8, 'Aide une ammsso avec un moyen de locomotion', '2020-10-06', 3, 1, 6),
(9, 'Transport de personnes pour le volley', '2020-12-17', 2, 1, 5),
(10, 'Transport de personnes pour le foot', '2020-12-15', 3, 1, 4),
(11, 'Transport de personnes pour un sallon', '2020-12-18', 4, 0, 7),
(12, 'Aide installation tables', '2020-12-14', 3, 0, 4),
(13, 'Portes ouvertes', '2020-12-16', 6, 0, 2),
(14, 'Aide au rangement', '2020-12-14', 3, 1, 7),
(15, 'Transport lors du trophei', '2021-02-10', 5, 1, 3);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `eleve`
--
ALTER TABLE `eleve`
  ADD PRIMARY KEY (`eleve_id`);

--
-- Index pour la table `identifiant`
--
ALTER TABLE `identifiant`
  ADD PRIMARY KEY (`nomUtil`),
  ADD KEY `eleve_id_fkk` (`eleve_id`);

--
-- Index pour la table `nn`
--
ALTER TABLE `nn`
  ADD KEY `eleve_id_f` (`eleve_id`),
  ADD KEY `tea_id_f` (`tea_id`);

--
-- Index pour la table `tea`
--
ALTER TABLE `tea`
  ADD PRIMARY KEY (`tea_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `eleve`
--
ALTER TABLE `eleve`
  MODIFY `eleve_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `tea`
--
ALTER TABLE `tea`
  MODIFY `tea_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `identifiant`
--
ALTER TABLE `identifiant`
  ADD CONSTRAINT `eleve_id_fkk` FOREIGN KEY (`eleve_id`) REFERENCES `eleve` (`eleve_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `nn`
--
ALTER TABLE `nn`
  ADD CONSTRAINT `eleve_id_f` FOREIGN KEY (`eleve_id`) REFERENCES `eleve` (`eleve_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `tea_id_f` FOREIGN KEY (`tea_id`) REFERENCES `tea` (`tea_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
